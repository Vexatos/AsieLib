package mekanism.api.reactor;

public interface INeutronCapture extends IReactorBlock
{
	public int absorbNeutrons(int neutrons);
}
