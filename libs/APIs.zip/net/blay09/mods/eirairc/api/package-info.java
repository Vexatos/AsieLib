/**
 * Created by Blay09 on 01.08.2014.
 */
@API(owner = "eirairc", apiVersion = "1.0", provides = "EiraIRC|API")
package net.blay09.mods.eirairc.api;

import cpw.mods.fml.common.API;