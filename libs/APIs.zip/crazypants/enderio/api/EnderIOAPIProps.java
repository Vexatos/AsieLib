package crazypants.enderio.api;

public final class EnderIOAPIProps {
  
  private EnderIOAPIProps() {}
  
  public static final String VERSION = "0.0.1";

}
