package mods.immibis.redlogic.api.wiring;

/**
 * Marker interface for uninsulated red alloy wire.
 */
public interface IBareRedstoneWire extends IRedstoneWire {

}
