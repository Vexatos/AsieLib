@API(apiVersion = "8.0.0", owner = "Mekanism", provides = "MekanismAPI|infuse")
package mekanism.api.infuse;
import cpw.mods.fml.common.API;